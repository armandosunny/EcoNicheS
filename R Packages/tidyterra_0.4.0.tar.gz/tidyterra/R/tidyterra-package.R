#' @keywords internal
"_PACKAGE"

#' @importFrom ggplot2 aes after_stat
#' @importFrom rlang .data
#' @importFrom grDevices terrain.colors rgb
#' @importFrom tibble as_tibble
NULL

#' @export
ggplot2::aes
