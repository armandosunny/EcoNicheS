list(
  rd_family_title = list(
    coerce = "Coercing objects:",
    tibble.methods = "Other tibble methods:",
    dplyr.methods = "Other dplyr methods:",
    dplyr.rows = "Other dplyr verbs that operate on rows:",
    dplyr.cols = "Other dplyr verbs that operate on columns:",
    dplyr.groups = "Other dplyr verbs that operate on group of rows:",
    dplyr.pairs = "Other dplyr verbs that operate on pairs Spat*/data.frame:",
    tidyr.method = "Other tidyr methods:",
    ggplot2.utils = "Other ggplot2 utils:",
    ggplot2.methods = "Other ggplot2 methods:",
    joins = "Other joins:",
    grouping = "Other grouping functions:",
    gradients = "Other gradient scales and palettes for hypsometry:"
  )
)
