library(testthat)
library(tidyterra)

test_check("tidyterra")
